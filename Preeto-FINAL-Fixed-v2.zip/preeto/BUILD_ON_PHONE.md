# Preeto build

This project is configured for Java 17, Android SDK 36, AGP 9.1.1 and Gradle 9.3.1.

The app currently does not apply the KSP plugin and does not use Room/Moshi code generation.
The GitHub Actions workflow performs a clean extraction before building so stale project files cannot survive from an older ZIP.
