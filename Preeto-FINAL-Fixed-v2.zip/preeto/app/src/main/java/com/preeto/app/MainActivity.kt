package com.preeto.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.preeto.app.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      MyApplicationTheme {
        PreetoAppScreen()
      }
    }
  }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PreetoAppScreen() {
  var webViewInstance by remember { mutableStateOf<WebView?>(null) }
  var pendingPermissionRequest by remember { mutableStateOf<PermissionRequest?>(null) }

  // Permission launcher for Android Runtime permissions (Microphone & Camera for live rooms)
  val permissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestMultiplePermissions()
  ) { permissions ->
    val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
    val cameraGranted = permissions[Manifest.permission.CAMERA] ?: false

    pendingPermissionRequest?.let { request ->
      val grantedResources = mutableListOf<String>()
      if (audioGranted) {
        grantedResources.add(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
      }
      if (cameraGranted) {
        grantedResources.add(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
      }
      if (grantedResources.isNotEmpty()) {
        request.grant(grantedResources.toTypedArray())
      } else {
        request.deny()
      }
      pendingPermissionRequest = null
    }
  }

  // Request initial permissions on launch for smooth voice room experience
  LaunchedEffect(Unit) {
    permissionLauncher.launch(
      arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CAMERA
      )
    )
  }

  // Handle Android back button
  BackHandler(enabled = webViewInstance?.canGoBack() == true) {
    webViewInstance?.goBack()
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF1C0F2E))
      .statusBarsPadding()
      .navigationBarsPadding()
      .imePadding()
  ) {
    AndroidView(
      modifier = Modifier.fillMaxSize(),
      factory = { context ->
        WebView(context).apply {
          settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(false)
          }

          setBackgroundColor(0xFF1C0F2E.toInt())

          CookieManager.getInstance().setAcceptCookie(true)
          CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

          webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
              return false
            }
          }

          webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
              if (request == null) return

              val neededPermissions = mutableListOf<String>()
              for (resource in request.resources) {
                if (resource == PermissionRequest.RESOURCE_AUDIO_CAPTURE) {
                  if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    neededPermissions.add(Manifest.permission.RECORD_AUDIO)
                  }
                }
                if (resource == PermissionRequest.RESOURCE_VIDEO_CAPTURE) {
                  if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    neededPermissions.add(Manifest.permission.CAMERA)
                  }
                }
              }

              if (neededPermissions.isEmpty()) {
                request.grant(request.resources)
              } else {
                pendingPermissionRequest = request
                permissionLauncher.launch(neededPermissions.toTypedArray())
              }
            }
          }

          loadUrl("file:///android_asset/index.html")
          webViewInstance = this
        }
      },
      update = {
        webViewInstance = it
      }
    )
  }
}
