# Preeto — phone build

This project is prepared for a cloud build from a phone.

1. Create a GitHub repository and upload this project.
2. Open Actions -> Build Preeto APK -> Run workflow.
3. After the run completes, open the workflow run and download the `preeto-v29-debug` artifact.

The app id is `com.preeto.app`, versionCode 29, versionName 2.9.0.
